import sys

from array import array
from copy import copy, deepcopy
from mmap import mmap
from os.path import splitext
from sys import getsizeof
from string import ascii_uppercase, ascii_lowercase
from traceback import format_exc

from .Defs.Constants import *

#Tag_Obj and Tag_Blocks need to circularly reference each other.
#In order to do this properly, each module tries to import the other.
#If one succeeds then it provides itself as a reference to the other.
'''try to import the Tag_Obj module. if it fails then
its because the Tag_Obj module is already being built'''
try:
    from .Objs import Tag_Obj
    Tag_Obj.Tag_Blocks = sys.modules[__name__]
except ImportError: pass


A_to_Z_UL_Case = ascii_uppercase + ascii_lowercase + '_'
A_to_Z_UL_Case_0_to_9 = A_to_Z_UL_Case + '0123456789'



class Tag_Block(list):    
    """
    Tag_Blocks are the sole method of storing structure data.
    They are comparable to a mutable version of namedtuples.
    They function as a list where each entry can be accessed
    by its attribute name defined in the descriptor.

    For example: If the value in key "0" in the descriptor of the
    object "Block" has a key:value pair of "NAME":"Data", then doing:
    
    Block[0] = "here's a string"
    
    is the same as doing:
    
    Block.Data = "here's a string"
    """
    
    __slots__ = ("DESC", "PARENT")

    def __init__(self, Desc=None, Init_Block=None, Parent=None, **kwargs):
        '''docstring'''
        
        #This section of code might end up being removed or replaced
        '''The Type section of it needs to exist for now though in order
        to allow the default value of Field_Types to be set to Tag_Blocks'''

        if Desc is None:
            if kwargs.get('Type') is None:
                raise TypeError("Cannot construct Tag_Block without " +
                                "a descriptor or a valid Type.")
            #if there is no descriptor provided, then
            #a unique, bare bones one will be used to
            #make sure the object works properly.
            Desc = {ATTR_MAP:{}, ATTR_OFFSETS:{}, SIZE:0,
                    ENTRIES:0, TYPE:kwargs.get('Type'),
                    NAME:kwargs.get('Name', "UNNAMED"),
                    GUI_NAME:kwargs.get('Gui_Name', "UNNAMED")}

        object.__setattr__(self, 'PARENT', Parent)
        if Desc is not None:
            object.__setattr__(self, "DESC", Desc)
        if self.DESC is None:
            raise TypeError("Cannot construct Tag_Block without a descriptor.")
        
        self.Read(Init_Block, **kwargs)
                 


    def __getitem__(self, Index):
        '''enables getting attributes by providing
        the attribute name string as an index'''
        if isinstance(Index, (int, slice)):
            return list.__getitem__(self, Index)
        else:
            return self.__getattr__(Index)


    def __setitem__(self, Index, New_Value):
        '''enables setting attributes by providing
        the attribute name string as an index'''
        if isinstance(Index, int):
            #handle accessing negative indexes
            if Index < 0:
                Index += len(self)
                
            Curr_Value = list.__getitem__(self, Index)
            '''If the value being set is a Tag_Block
            and the descriptors are different, then
            this objects descriptor needs to be updated'''
            

            #make sure the object's type matches what was in it
            if ((isinstance(New_Value, Tag_Block) and
                 isinstance(Curr_Value, Tag_Block)) and
                (not self.TYPE.Is_Array and
                 id(Curr_Value.DESC) != id(New_Value.DESC))):
                
                '''if this is an array, dont worry about
                the descriptor since its list indexes
                are instanced objects, not attributes'''
                self.Set_Desc(Index, New_Value.DESC)
            else:
                '''try to get the descriptor from the object itself
                and if we cant we try to get it from the parent'''
                try:
                    Valid_Py_Type = Curr_Value.DESC[TYPE].Py_Type
                except Exception:
                    if self.TYPE.Is_Array:
                        Valid_Py_Type = self.DESC[ARRAY_ELEMENT][TYPE].Py_Type
                    else:
                        Valid_Py_Type = self.DESC[Index][TYPE].Py_Type
                    
                if not isinstance(New_Value, Valid_Py_Type):
                    try:   Index = self.DESC[Index][NAME]
                    except Exception: pass
                    raise TypeError(("Proper python type for attribute " +
                                     "'%s' in object '%s' is %s, not %s") %
                                     (Index, self.NAME,
                                      Valid_Py_Type, type(New_Value)))

            #now that the descriptor has been successfully set
            #and the type verified, set the item's new value
            list.__setitem__(self, Index, New_Value)

            '''if the object being placed in the Tag_Block
            has a 'PARENT' attribute, set this block to it'''
            try:   object.__setattr__(New_Attr, 'PARENT', self)
            except Exception: pass

            if not self.TYPE.Is_Array and self.Get_Desc(TYPE,Index).Is_Var_Size:
                #try to set the size of the attribute
                try:   self.Set_Size(None, Index)
                except NotImplementedError: pass
                except AttributeError: pass
        else:
            self.__setattr__(Index, New_Value)


    def __delitem__(self, Index):
        '''enables deleting attributes by providing
        the attribute name string as an index'''
        
        if isinstance(Index, int):
            #handle accessing negative indexes
            if Index < 0:
                Index += len(self)
            list.__delitem__(self, Index)
            
            '''if this is an array, dont worry about
            the descriptor since its list indexes
            aren't attributes, but instanced objects'''
            if self.TYPE.Is_Array:
                self.Set_Size(1, None, '-')
            else:
                self.Del_Desc(Index)
                
                try:   self.Set_Size(0, Index)
                except NotImplementedError: pass
                except AttributeError: pass
                
        elif type(Index) == slice:            
            '''if this is an array, dont worry about
            the descriptor since its list indexes
            aren't attributes, but instanced objects'''
            if self.TYPE.Is_Array:
                Old_Size = len(self)
                list.__delitem__(self, Index)
                self.Set_Size(Old_Size-len(self), None, '-')
            else:
                start, stop, step = Index.indices(len(self))
                if start < stop:
                    start, stop = stop, start
                if step > 0:
                    step = -step
                    
                for i in range(start-1, stop-1, step):
                    self.Del_Desc(i)
                    list.__delitem__(self, i)
                    
                    try:   self.Set_Size(0, i)
                    except NotImplementedError: pass
                    except AttributeError: pass
        else:
            self.__delattr__(Index)


    def __getattr__(self, Name):
        '''docstring'''
        if Name in object.__getattribute__(self, "__slots__"):
            return object.__getattribute__(self, Name)
        else:
            Desc = object.__getattribute__(self, "DESC")
            
            if Name in Desc[ATTR_MAP]:
                return self[Desc[ATTR_MAP][Name]]
            elif Name in Desc:
                return Desc[Name]
            else:
                if NAME in Desc:
                    raise AttributeError("'%s' of type %s has no attribute '%s'"
                                         %(Desc[NAME], type(self), Name))
                else:
                    raise AttributeError("%s has no attribute '%s'"
                                         %(type(self), Name))


    def __setattr__(self, Name, New_Value):
        '''docstring'''
        if Name in object.__getattribute__(self, '__slots__'):
            if Name == 'CHILD':
                Curr_Value = object.__getattribute__(self, 'CHILD')

                if ((isinstance(New_Value, Tag_Block) and
                     isinstance(Curr_Value, Tag_Block)) and
                    id(Curr_Value.DESC) != id(New_Value.DESC)):
                    self.Set_Desc('CHILD', New_Value.DESC)
                else:
                    Desc = object.__getattribute__(self, 'DESC')
                    
                    '''try to get the descriptor from the object itself
                    and if we cant we try to get it from the parent'''
                    try:
                        Valid_Py_Type = Curr_Value.DESC[TYPE].Py_Type
                    except Exception:
                        if Desc[TYPE].Is_Array:
                            Valid_Py_Type = Desc[ARRAY_ELEMENT][TYPE].Py_Type
                        else:
                            Valid_Py_Type = Desc['CHILD'][TYPE].Py_Type
                        
                    if not isinstance(New_Value, Valid_Py_Type):
                        raise TypeError(("Proper python type for attribute " +
                                         "'%s' in object '%s' is %s, not %s") %
                                         ('CHILD', self.NAME,
                                          Valid_Py_Type, type(New_Value)))

                        
                object.__setattr__(self, 'CHILD', New_Value)
                
                if self.Get_Desc(TYPE, 'CHILD').Is_Var_Size:
                    #try to set the size of the attribute
                    try:   self.Set_Size(None, 'CHILD')
                    except NotImplementedError: pass
                    except AttributeError: pass
            else:
                object.__setattr__(self, Name, New_Value)
        else:
            Desc = object.__getattribute__(self, "DESC")
            if Name == 'CHILD':
                if NAME in Desc:
                    raise AttributeError(("'%s' of type %s has no "+
                                          "slot for a CHILD.") %
                                         (Desc[NAME], type(self)))
                else:
                    raise AttributeError("%s has no slot for a CHILD."%
                                         type(self))
            
            if Name in Desc[ATTR_MAP]:
                self.__setitem__(Desc[ATTR_MAP][Name], New_Value)
            elif Name in Desc:
                self.Set_Desc(Name, New_Value)
            else:
                if NAME in Desc:
                    raise AttributeError(("'%s' of type %s has no "+
                                          "attribute '%s'") %
                                         (Desc[NAME], type(self), Name))
                else:
                    raise AttributeError("%s has no attribute '%s'"%
                                         (type(self), Name))



    def _Bin_Size(self, Block, Sub_Struct=False):
        '''docstring'''
        Size = 0
        if isinstance(Block, Tag_Block):
            #get the size of this structure if it's not a substruct
            if Block.TYPE.Is_Struct and not Sub_Struct:
                Size = Block.Get_Size()
                Sub_Struct = True

            #loop for each of the attributes
            for i in range(len(Block)):
                Sub_Block = Block[i]
                if isinstance(Sub_Block, Tag_Block):
                    if Sub_Block.TYPE.Is_Container:
                        for Sub_Sub_Block in Sub_Block:
                            Size += self._Bin_Size(Sub_Sub_Block)
                    else:
                        Size += self._Bin_Size(Sub_Block, Sub_Struct)
                else:
                    if not Sub_Struct:
                        Size += Block.Get_Size(i)

            #loop for each of the sub structures
            if hasattr(Block, 'CHILD'):
                if isinstance(Block.CHILD, Tag_Block):
                    Size += Block._Bin_Size(Block.CHILD)
                else:
                    Size += Block.Get_Size('CHILD')
            
        return Size


    
    @property
    def Bin_Size(self):
        '''Returns the size of this Tag_Block and all Tag_Blocks
        parented to it. This size isn't how much space it takes up
        in RAM, but how much it would take up if written to a buffer'''
        return self._Bin_Size(self)

    def Get_Tag(self):
        '''This function upward navigates the Tag_Block
        structure it is a part of until it finds a block
        with the attribute "Tag_Data", and returns it.

        Raises LookupError if the Tag is not found'''
        Tag = self
        while hasattr(Tag, 'PARENT'):
            Tag = Tag.PARENT
            
            '''check if the object is a Tab_Object, but not a
            Tag_Block. Only a Tag should fit these criteria'''
            if isinstance(Tag, Tag_Obj.Tag_Obj):
                return Tag
            
        raise LookupError("Could not locate parent Tag object.")
    

    def Get_Neighbor(self, Path, Block=None, Array_Map=None):
        """Given a path to follow, this function will
        navigate neighboring blocks until the path is
        exhausted and return the last block."""
        if not isinstance(Path, str):
            raise TypeError("'Path' argument must be of type " +
                            "'%s', not '%s'" % (str, type(Path)) )
        
        Path_Fields = Path.split('.')
        
        if Array_Map is None:
            Array_Map = {}

        #if a starting block wasn't provided, or it was
        #and it's not a Tag_Block with a parent reference
        #we need to set it to something we can navigate from
        if not hasattr(Block, 'PARENT'):
            try:
                if Block.TYPE.Is_Array:
                    Array_Map[Block.NAME] = self.index(Block)
            except Exception: pass

            if Path_Fields and Path_Fields[0] == "":
                '''If the first direction in the path is
                to go to the parent, set Block to self
                (because Block may not be navigable from)
                and delete the first path direction'''
                Block = self
                del Path_Fields[0]
            else:
                '''if the first path isn't "Go to parent",
                then it means it's not a relative path.
                Thus the path starts at the Tag_Data root'''
                Block = self.Get_Tag().Tag_Data
            
        try:
                
            for field in Path_Fields:
                if field == '':
                    New_Block = Block.PARENT

                    #if the upper blocks type is an array then
                    #we need to store the index we entered into
                    if New_Block.TYPE.Is_Array:
                        try:    Array_Map[Block.NAME] = New_Block.index(Block)
                        except Exception: pass
                else:
                    if field[0] == '[' and field[-1] == ']':
                        New_Block = Block[int(field[1:-1])]
                    elif field[0] == '{' and field[-1] == '}':
                        New_Block = Block[Array_Map[field[1:-1]]]
                    elif ((field[0] == '"' and field[-1] == '"') or
                          (field[0] == "'" and field[-1] == "'")):
                        """If the index is yet another path
                        then call 'Get_Neighbor' on it. Gotta
                        add the '.' to make sure it knows to
                        work from this block and not the root"""
                        New_Block = Block.__getitem__(Block.Get_Neighbor\
                                                      ('.'+field[1:-1],
                                                       None, Array_Map))
                    else:
                        New_Block = Block.__getattr__(field)

                    #if the upper blocks type is an array then
                    #we need to store the index we entered into
                    if Block.TYPE.Is_Array:
                        try: Array_Map[New_Block.NAME] = Block.index(New_Block)
                        except Exception: pass

                #replace the block to the new
                #block to continue the cycle
                Block = New_Block
        except Exception:
            try:    self_name  = self.NAME
            except Exception: self_name  = type(self)
            try:    block_name = Block.NAME
            except Exception: block_name = type(Block)
            try:    field
            except Exception: field = ''
            
            raise AttributeError(("Path string to neighboring block is " +
                                  "invalid.\nStarting block was '%s'. "+
                                  "Couldnt find '%s' in '%s'.\n" +
                                  "Full path was '%s'") %
                                 (self_name, field, block_name, Path))
        return Block


    def Get_Size(self, Attr_Name=None):
        '''docstring'''

        if type(Attr_Name) == int:
            Block = self[Attr_Name]
            Block_Name = Attr_Name
            Desc = self.DESC[Attr_Name]
        elif type(Attr_Name) == str:
            Block = self.__getattr__(Attr_Name)
            Block_Name = Attr_Name
            try:
                Desc = self.DESC[self.DESC[ATTR_MAP][Attr_Name]]
            except Exception:
                Desc = self.DESC[Attr_Name]
        else:
            Block = self
            Block_Name = self.NAME
            Desc = self.DESC

            
        if SIZE in Desc:
            Size = Desc[SIZE]
            
            if isinstance(Size, int):
                return Size
            elif isinstance(Size, str):
                '''get the pointed to Size data by traversing the tag
                structure along the path specified by the string'''
                return self.Get_Neighbor(Size, Block)
            elif hasattr(Size, "__call__"):
                '''find the pointed to Size data by
                calling the provided function'''
                if hasattr(Block, PARENT):
                      Parent = Block.PARENT
                else: Parent = self

                try:
                    Tag = self.Get_Tag()
                except Exception:
                    Tag = None
                    
                return Size(Tag = Tag, Attr_Name=Attr_Name,
                            Parent=Parent, Block=Block)
            else:
                raise TypeError(("Size specified in '%s' is not a valid type. "+
                                 "Expected int, str, or function. Got %s.") %
                                (Block_Name, type(Size)) )
        else:
            #use the size calculation routine of the Field_Type
            return Desc[TYPE].Size_Calc(Block)



    def Get_Meta(self, Meta_Name, Attr_Name=None):
        '''docstring'''

        if type(Attr_Name) == int:
            Block = self[Attr_Name]
            Block_Name = Attr_Name
            Desc = self.DESC[Attr_Name]
        elif type(Attr_Name) == str:
            Block = self.__getattr__(Attr_Name)
            Block_Name = Attr_Name
            try:
                Desc = self.DESC[self.DESC[ATTR_MAP][Attr_Name]]
            except Exception:
                Desc = self.DESC[Attr_Name]
        else:
            Block = self
            Block_Name = self.NAME
            Desc = self.DESC

            
        if Meta_Name in Desc:
            Meta = Desc[Meta_Name]
            
            if isinstance(Meta, int):
                return Meta
            elif isinstance(Meta, str):
                '''get the pointed to meta data by traversing the tag
                structure along the path specified by the string'''
                return self.Get_Neighbor(Meta, Block)
            elif hasattr(Meta, "__call__"):
                '''find the pointed to meta data by
                calling the provided function'''
                if hasattr(Block, PARENT):
                    Parent = Block.PARENT
                else:
                    Parent = self

                try:
                    Tag = self.Get_Tag()
                except Exception:
                    Tag = None
                    
                return Meta(Tag = Tag, Attr_Name=Attr_Name,
                            Parent=Parent, Block=Block)
            else:
                raise LookupError("Couldnt locate meta info")
        else:
            raise AttributeError("'%s' does not exist in '%s'."
                                 % (Meta_Name,Block_Name))

        
    def Get_Desc(self, Desc_Key, Attr_Name=None):
        '''Returns the value in the object's descriptor
        under the key "Desc_Key". If Attr_Name is not None,
        the descriptor being searched for "Desc_Key" will
        instead be the attribute "Attr_Name".'''
        Desc = object.__getattribute__(self, "DESC")

        '''if we are getting something in the descriptor
        of one of this Tag_Block's attributes, then we
        need to set Desc to the attributes descriptor'''
        if Attr_Name is not None:
            if isinstance(Attr_Name, int) or Attr_Name in Desc:
                Desc = Desc[Attr_Name]
            else:
                try:
                    try:
                        Desc = Desc[Desc[ATTR_MAP][Attr_Name]]
                    except Exception:
                        Desc = Desc[Attr_Name]
                except Exception:
                    raise KeyError(("Could not locate '%s' in the descriptor "+
                                    "of '%s'.") % (Attr_Name, self.NAME))

        '''Try to return the descriptor value under the key "Desc_Key" '''
        if Desc_Key in Desc:
            return Desc[Desc_Key]
        elif ATTR_MAP in Desc and Desc_Key in Desc[ATTR_MAP]:
            return Desc[Desc[ATTR_MAP][Desc_Key]]
        else:
            if Attr_Name is not None:
                raise KeyError(("Could not locate '%s' in the sub-descriptor "+
                                "'%s' in the descriptor of '%s'") %
                               (Desc_Key, Attr_Name, self.NAME))
            else:
                raise KeyError(("Could not locate '%s' in the descriptor " +
                                "of '%s'.") % (Desc_Key, self.NAME))


    def Read(self, Init_Block=None, **kwargs):
        '''This function will initialize all of a Tag_Blocks attributes to
        their default value and adding ones that dont exist. An Init_Block
        can be provided with which to initialize the values of the block.'''
        Raw_Data = Filepath = None
        Init_Attrs = True
        Attr_Name = None

        #if an Init_Block was provided, make sure it can be used
        if (Init_Block is not None and
            not (hasattr(Init_Block, '__iter__') and
                 hasattr(Init_Block, '__len__'))):
            raise TypeError("Init_Block must be an iterable with a length.")

        if 'Init_Attrs' in kwargs:
            Init_Attrs = bool(kwargs['Init_Attrs'])
        if 'Filepath' in kwargs:
            Filepath = kwargs['Filepath']
        if 'Raw_Data' in kwargs:
            Raw_Data = kwargs['Raw_Data']
        if 'Attr_Name' in kwargs:
            Attr_Name = kwargs['Attr_Name']

        #figure out what the Tag_Block is being built from
        if Filepath is not None:
            if Raw_Data is not None:
                raise TypeError("Provide either Raw_Data " +
                                "or a Filepath, but not both.") 

            '''try to open the tag's path as the raw tag data'''
            try:
                with open(Filepath, 'r+b') as Tag_File:
                    Raw_Data = mmap(Tag_File.fileno(), 0)
            except Exception:
                raise IOError('Input filepath for reading Tag_Block ' +
                              'from was invalid or the file could ' +
                              'not be accessed.\n    ' + Filepath)
            
        if (Raw_Data is not None and
            not(hasattr(Raw_Data, 'read') or hasattr(Raw_Data, 'seek'))):
            raise TypeError('Cannot build a Tag_Block without either'
                            + ' an input path or a readable buffer')
            
        Desc = object.__getattribute__(self, "DESC")
        if Attr_Name is not None and Raw_Data is not None:
            #if we are reading or initializing just one attribute
            if Attr_Name in Desc[ATTR_MAP]:
                Attr_Name = self[Desc[ATTR_MAP][Name]]
            elif isinstance(Attr_Name, int) and Name in Desc:
                Attr_Name = Desc[Name]
            
            Desc = self.Get_Desc(Attr_Name)
        else:
            #if we are reading or initializing EVERY attribute

            #clear the block and set it to the right number of empty indices
            list.__delitem__(self, slice(None, None, None))
                        
            if Desc[TYPE].Is_Array:
                list.extend(self, [None]*self.Get_Size())
            else:
                list.extend(self, [None]*Desc[ENTRIES])

            '''If the Init_Block is not None then try
            to use it to populate the Tag_Block'''
            if isinstance(Init_Block, dict):
                '''Since dict keys can be strings we assume that the
                reason a dict was provided is to set the attributes
                by name rather than index.
                So call self.__setattr__ instead of self.__setitem__'''
                for Name in Init_Block:
                    self.__setattr__(Name, Init_Block[Name])
            elif Init_Block is not None:
                '''loop over the Tag_Block and copy the entries
                from Init_Block into the Tag_Block. Make sure to
                loop as many times as the shortest length of the
                two so as to prevent IndexErrors.'''
                for i in range(min(len(self), len(Init_Block))):
                    self.__setitem__(i, Init_Block[i])
        

        if Raw_Data is not None:
            #build the structure from raw data
            C_Off = R_Off = 0
            Tag_Test = False
            if 'Root_Offset' in kwargs:
                R_Off = kwargs['Root_Offset']
            if 'Offset' in kwargs:
                C_Off = kwargs['Offset']
            if 'Tag_Test' in kwargs:
                Tag_Test = kwargs['Tag_Test']

            try:
                #Figure out if the parent is this Tag_Block or its parent.
                if Attr_Name is None:
                    Parent = self
                else:
                    Parent = self.PARENT
                
                Desc[TYPE].Reader(Parent, Raw_Data, Attr_Name,
                                  R_Off, C_Off, Tag_Test = Tag_Test)
            except Exception:
                raise IOError('Error occurred while trying to '+
                              'read Tag_Block from file.')
                
        elif Init_Attrs:
            #initialize the attributes
            
            if Desc[TYPE].Is_Array:
                '''This Tag_Block is an array, so the type of each
                element should be the same then initialize it'''
                try:
                    Attr_Type = Desc[ARRAY_ELEMENT][TYPE]
                    Py_Type = Attr_Type.Py_Type
                except Exception: 
                    raise TypeError("Could not locate the array element " +
                                    "descriptor.\n Could not initialize array.")

                #loop through each element in the array and initialize it
                for i in range(len(self)):
                    if list.__getitem__(self, i) is None:
                        Attr_Type.Reader(self, Attr_Name, i)
            else:
                for i in range(len(self)):
                    '''Only initialize the attribute
                    if a value doesnt already exist'''
                    if list.__getitem__(self, i) is None:
                        Attr_Desc = Desc[i]
                        #if there is a default value,
                        #but its not a Tag_Block type
                        if (DEFAULT in Attr_Desc and not
                            isinstance(Attr_Desc[DEFAULT], type)):
                            '''set the value to the default
                            defined in the descriptor'''
                            self.__setitem__(i, deepcopy(Attr_Desc[DEFAULT]))
                        else:
                            Attr_Desc[TYPE].Reader(self, Attr_Index=i)

            '''Only initialize the child if the block has a
            child and a value for it doesnt already exist.'''
            if 'CHILD' in Desc and object.__getattribute__(self, CHILD) is None:
                Attr_Desc = Desc['CHILD']
                
                #if there is a default value,
                #but its not a Tag_Block type
                if (DEFAULT in Attr_Desc and not
                    isinstance(Attr_Desc[DEFAULT], type)):
                    #set the value to the default defined in the descriptor
                    self.__setattr__('CHILD', deepcopy(Attr_Desc[DEFAULT]))
                else:
                    #call the reader of the child type
                    Attr_Desc[TYPE].Reader(self, Attr_Index='CHILD')


    def Write(self, **kwargs):
        """This function will write this Tag_Block to the provided
        file path/buffer. The name of the block will be used as the
        extension. This function is used ONLY for writing a piece
        of a tag to a file/buffer, not the entire tag. DO NOT CALL
        this function when writing a whole tag at once."""
        
        Mode = 'file'
        Filepath = None
        Block_Buffer = None

        Offset = 0
        
        Tag = None
        Temp = False
        Calculate_Pointers = True

        if 'Tag' in kwargs:
            Tag = kwargs["Tag"]
        else:
            try:   Tag = self.Get_Tag()
            except Exception: pass
        if 'Calculate_Pointers' in kwargs:
            Calculate_Pointers = bool(kwargs["Calculate_Pointers"])
        else:
            try:   Calculate_Pointers = Tag.Calculate_Pointers
            except Exception: pass
        
        if kwargs.get("Filepath"):
            Mode = 'file'
            Filepath = kwargs["Filepath"]
        elif kwargs.get('Buffer'):
            Mode = 'buffer'
            Block_Buffer = kwargs['Buffer']

        #if the filepath wasn't provided, try to use
        #a modified version of the parent tags path 
        if Filepath is None and Block_Buffer is None:
            try:
                Filepath = splitext(Tag.Tag_Path)[0]
            except Exception:
                raise IOError('Output filepath was not provided and could ' +
                              'not generate one from parent tag object.')
        if 'Offset' in kwargs:
            Offset = kwargs["Offset"]
        if 'Temp' in kwargs:
            Temp = bool(kwargs["Temp"])
            
        
        if Filepath is not None and Block_Buffer is not None:
            raise TypeError("Provide either a Buffer " +
                            "or a Filepath, but not both.") 
            
        if Mode == 'file':
            #if the filepath doesnt have an extension, give it one
            if splitext(Filepath)[-1] == '':
                try:
                    Filepath += '.' + self.NAME + ".blok"
                except Exception:
                    Filepath += ".unnamed.blok"
            
            if Temp:
                Filepath += ".temp"

            try: Block_Buffer = open(Filepath, 'wb')
            except Exception:
                raise IOError('Output filepath for writing block was invalid ' +
                              'or the file could not be created.\n    %s' %
                              Filepath)

        '''make sure the buffer has a valid write and seek routine'''
        if not (hasattr(Block_Buffer,'write') or hasattr(Block_Buffer,'seek')):
            raise TypeError('Cannot write a Tag_Block without either'
                            + ' an output path or a writable buffer')

        
        '''try to write the block to the buffer'''
        try:
            #if we need to calculate the pointers, do so
            if Calculate_Pointers:
                self._Set_Pointers(Offset)

            #make a file as large as the tag is calculated to fill
            Block_Buffer.write(bytes(self.Bin_Size))
            self.TYPE.Writer(self, Block_Buffer, None, 0, Offset)
            
            #return the filepath or the buffer in case
            #the caller wants to do anything with it
            if Mode == 'file':
                try:    Block_Buffer.close()
                except Exception: pass
                return Filepath
            else:
                return Block_Buffer
        except Exception:
            if Mode == 'file':
                try:    Block_Buffer.close()
                except Exception: pass
            try: os.remove(Filepath)
            except Exception: pass
            raise IOError("Exception occurred while attempting" +
                          " to write the tag block:\n", Filepath)


class Tag_Parent_Block(Tag_Block):
    '''This block allows a reference to the child
    block it describes to be stored as well as a
    reference to whatever block it is parented to'''
    __slots__ = ("DESC", 'PARENT', 'CHILD')
    
    def __init__(self, Desc=None, Init_Block=None,
                 Child=None, Parent=None, **kwargs):
        object.__setattr__(self, 'CHILD', Child)
        Tag_Block.__init__(self, Desc, Init_Block, Parent, **kwargs)

    def __setattr__(self, Name, Value):
        Tag_Block.__setattr__(self, Name, Value)
        #if this object is being given a child then try to
        #automatically give the child this object as a parent
        if Name == 'CHILD':
            try:
                if object.__getattribute__(Value, 'PARENT') != self:
                    object.__setattr__(Value, 'PARENT', self)
            except Exception: pass
