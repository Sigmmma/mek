Dont distribute this. The library is still in production and is buggy.

Happy hacking,
Moses of Egypt